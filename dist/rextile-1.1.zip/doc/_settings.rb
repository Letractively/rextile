
@head_nodes << '<link rel="stylesheet" type="text/css" media="screen" href="' + root_path + 'style_screen.css" />'
@head_nodes << '<link rel="stylesheet" type="text/css" media="print" href="' + root_path + 'style_print.css" />'

@crumbs << 'Rextile'

