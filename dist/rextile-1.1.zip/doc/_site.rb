
# Use Rextile's default template.
@template_path = '../templates/standard'
