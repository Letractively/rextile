require File.join( File.dirname( __FILE__ ), 'rextile' )

# Main
Rextile.new.glob
